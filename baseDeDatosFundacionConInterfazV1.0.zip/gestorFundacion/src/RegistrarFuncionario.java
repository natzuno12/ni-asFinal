import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.UsuarioDTO;
import controlador.TipoUsuarioControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class RegistrarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;
	private JComboBox comboBoxGenero;
	private JComboBox comboBoxTipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrarFuncionario frame = new RegistrarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistrarFuncionario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(RegistrarFuncionario.class.getResource("/images/logo.jpg")));
		setTitle("Registrar Funcionario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 570, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblRegistrarFuncionario = new JLabel("REGISTRAR FUNCIONARIO");
		lblRegistrarFuncionario.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarFuncionario.setForeground(Color.RED);
		lblRegistrarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarFuncionario.setBounds(10, 11, 534, 45);
		contentPane.add(lblRegistrarFuncionario);

		JLabel label = new JLabel("Documento:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(10, 85, 194, 14);
		contentPane.add(label);

		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(214, 82, 156, 20);
		contentPane.add(txtDocumento);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					UsuarioControlador controlUsuario = new UsuarioControlador();
					UsuarioDTO usuario = new UsuarioDTO();
					usuario = controlUsuario.findByPk(Long.parseLong((txtDocumento.getText())));
					if(usuario.getDocumento() == 0){
					controlUsuario.insert(Long.parseLong(txtDocumento.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText(), " ", txtCelular.getText(), (String) comboBoxGenero.getSelectedItem() );
					TipoUsuarioControlador controlFuncionario = new TipoUsuarioControlador();
					controlFuncionario.insert((int) (Math.random() * 9999) + 1, Long.parseLong(txtDocumento.getText()), (String)comboBoxTipo.getSelectedItem());
					JOptionPane.showMessageDialog(null, "funcionario agregado");
					System.out.print("Operacion exitosa");
					}else {
						JOptionPane.showMessageDialog(null, "El funcionario ya existe");
					}
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al agregar funcionario");
					}
			}
		});
		btnRegistrar.setBounds(235, 288, 114, 31);
		contentPane.add(btnRegistrar);

		JLabel label_1 = new JLabel("Nombres:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(10, 110, 194, 14);
		contentPane.add(label_1);

		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(213, 107, 266, 20);
		contentPane.add(txtNombres);

		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(10, 132, 194, 14);
		contentPane.add(label_2);

		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(214, 129, 265, 20);
		contentPane.add(txtApellidos);

		JLabel label_3 = new JLabel("Celular:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(10, 155, 194, 14);
		contentPane.add(label_3);

		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(214, 152, 191, 20);
		contentPane.add(txtCelular);

		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(10, 180, 194, 14);
		contentPane.add(label_4);

		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(214, 177, 265, 20);
		contentPane.add(txtDireccion);

		JLabel label_5 = new JLabel("Genero:");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(10, 205, 194, 14);
		contentPane.add(label_5);

		comboBoxGenero = new JComboBox();
		comboBoxGenero.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		comboBoxGenero.setBounds(214, 202, 70, 20);
		contentPane.add(comboBoxGenero);
		
		JLabel lblTipoFuncionario = new JLabel("Tipo Funcionario:");
		lblTipoFuncionario.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTipoFuncionario.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTipoFuncionario.setBounds(10, 233, 194, 14);
		contentPane.add(lblTipoFuncionario);
		
		comboBoxTipo = new JComboBox();
		comboBoxTipo.setModel(new DefaultComboBoxModel(new String[] {"Psicologo", "Defensor"}));
		comboBoxTipo.setBounds(214, 230, 121, 20);
		contentPane.add(comboBoxTipo);
	}
}
