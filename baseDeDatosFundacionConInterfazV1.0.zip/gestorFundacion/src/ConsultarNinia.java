import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import DTO.NiniaDTO;
import DTO.RegistroSaludDTO;
import DTO.TipoUsuarioDTO;
import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.RegistroSaludControlador;
import controlador.TipoUsuarioControlador;
import controlador.UsuarioControlador;
import stack.StackArray;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class ConsultarNinia extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JTable table;
	private JLabel label;
	private JTextField txtDocumento;
	private JButton btnConsultar;
	private JLabel label_1;
	private JTextField textFecha;
	private JLabel label_2;
	private JTextField textPeso;
	private JLabel lblAlturacm;
	private JTextField textAltura;
	private JLabel label_4;
	private JTextField textTension;
	private JLabel label_5;
	private JTextField textDescripcion;
	private JButton btnVerFamiliares;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultarNinia frame = new ConsultarNinia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConsultarNinia() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ConsultarNinia.class.getResource("/images/logo.jpg")));
		setTitle("Consultar Ni\u00F1a");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1001, 687);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 91, 965, 219);
		
		label = new JLabel("Documento:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(113, 11, 133, 17);
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		txtDocumento = new JTextField();
		txtDocumento.setBounds(256, 11, 144, 20);
		txtDocumento.setColumns(10);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(283, 42, 116, 33);
		btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					NiniaControlador controlNinia = new NiniaControlador();
					UsuarioControlador controlUsuario = new UsuarioControlador();
					
					NiniaDTO ninia = controlNinia.findByPk(Long.parseLong(txtDocumento.getText()));		
					UsuarioDTO usuario = controlUsuario.findByPk(ninia.getUsuarioDocumento());
					
					DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
					while(dm.getRowCount()>0){
						dm.removeRow(0);
					}
					if(ninia.getUsuarioDocumento()!=0){
					int numCols = table.getModel().getColumnCount();
					Object[] fila = new Object[numCols];

					fila[0] = usuario.getDocumento();
					fila[1] = ninia.getId();
					fila[2] = usuario.getNombres();
					fila[3] = usuario.getApellidos();
					fila[4] = usuario.getDireccion();
					fila[5] = usuario.getEmail();
					fila[6] = usuario.getCelular();
					fila[7] = ninia.getDescripcionEntrada();
					((DefaultTableModel) table.getModel()).addRow(fila);
					
					RegistroSaludControlador controlRegistro = new RegistroSaludControlador();
					RegistroSaludDTO registro = controlRegistro.findByPk(ninia.getUsuarioDocumento());
					if(registro.getNiniaDocumento() != 0){
						textFecha.setText(registro.getFechaRestro().toGMTString());
						textAltura.setText(Double.toString(registro.getAltura()));
						textDescripcion.setText(registro.getDescripcionCondicion());
						textPeso.setText(Integer.toString(registro.getPeso()));
						textTension.setText(Integer.toString(registro.getTension()));
					}else{
						JOptionPane.showMessageDialog(null, "La ni�a no cuenta a�n con registro de salud");
					}
					}else{
						JOptionPane.showMessageDialog(null, "La ni�a consultada no existe en la base de datos");
					}
					
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al buscar la ni�a");
					}
			}
		});
		
		label_1 = new JLabel("Fecha de Registro:");
		label_1.setBounds(176, 367, 220, 17);
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textFecha = new JTextField();
		textFecha.setBounds(406, 367, 265, 17);
		textFecha.setColumns(10);
		
		label_2 = new JLabel("Peso:");
		label_2.setBounds(176, 395, 220, 17);
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textPeso = new JTextField();
		textPeso.setBounds(406, 395, 86, 20);
		textPeso.setColumns(10);
		
		lblAlturacm = new JLabel("Altura(cm):");
		lblAlturacm.setBounds(176, 421, 220, 17);
		lblAlturacm.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAlturacm.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textAltura = new JTextField();
		textAltura.setBounds(406, 421, 86, 20);
		textAltura.setColumns(10);
		
		label_4 = new JLabel("Tension:");
		label_4.setBounds(176, 447, 220, 17);
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textTension = new JTextField();
		textTension.setBounds(406, 447, 86, 20);
		textTension.setColumns(10);
		
		label_5 = new JLabel("Descripci\u00F3n:");
		label_5.setBounds(176, 474, 220, 17);
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textDescripcion = new JTextField();
		textDescripcion.setBounds(406, 473, 314, 73);
		textDescripcion.setColumns(10);
		
		btnVerFamiliares = new JButton("Ver familiares");
		btnVerFamiliares.setBounds(516, 578, 144, 42);
		btnVerFamiliares.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ConsultarFamiliar ventana = new ConsultarFamiliar();
				ventana.setVisible(true);
				ventana.consultarFamiliares(Long.parseLong(txtDocumento.getText()));
			}
		});
		btnVerFamiliares.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JButton btnNewButton = new JButton("A\u00F1adir Familiar");
		btnNewButton.setBounds(356, 578, 142, 42);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RegistroFamiliar ventana = new RegistroFamiliar();
				ventana.setVisible(true);
				ventana.setDocumentoNinia(Long.parseLong(txtDocumento.getText()));
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblRegistroDeSalud = new JLabel("REGISTRO DE SALUD");
		lblRegistroDeSalud.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroDeSalud.setBounds(356, 339, 233, 17);
		lblRegistroDeSalud.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Documento", "Id", "Nombres", "Apellidos", "Direccion", "Email", "Celular", "Descripcion"
			}
		));
		table.getColumnModel().getColumn(1).setPreferredWidth(34);
		table.getColumnModel().getColumn(2).setPreferredWidth(119);
		table.getColumnModel().getColumn(3).setPreferredWidth(130);
		table.getColumnModel().getColumn(4).setPreferredWidth(123);
		table.getColumnModel().getColumn(5).setPreferredWidth(147);
		table.getColumnModel().getColumn(6).setPreferredWidth(124);
		table.getColumnModel().getColumn(7).setPreferredWidth(135);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		contentPane.add(label);
		contentPane.add(txtDocumento);
		contentPane.add(btnConsultar);
		contentPane.add(btnNewButton);
		contentPane.add(btnVerFamiliares);
		contentPane.add(label_4);
		contentPane.add(lblAlturacm);
		contentPane.add(label_2);
		contentPane.add(label_1);
		contentPane.add(label_5);
		contentPane.add(textFecha);
		contentPane.add(textDescripcion);
		contentPane.add(textTension);
		contentPane.add(textAltura);
		contentPane.add(textPeso);
		contentPane.add(lblRegistroDeSalud);
		
		JButton btnConsultarTodas = new JButton("Consultar Todas");
		btnConsultarTodas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
				NiniaControlador controlNinia = new NiniaControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				
				StackArray<NiniaDTO> ninias = controlNinia.findAll();
				
				DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
				while(dm.getRowCount()>0){
					dm.removeRow(0);
				}
				
				for(int i=0 ; i<ninias.getSize()-1 ; i++){
					
					NiniaDTO ninia = ninias.pop();
					
					UsuarioDTO usuario = controlUsuario.findByPk(ninia.getUsuarioDocumento());
					
					
					int numCols = table.getModel().getColumnCount();
					Object[] fila = new Object[numCols];

					fila[0] = usuario.getDocumento();
					fila[1] = ninia.getId();
					fila[2] = usuario.getNombres();
					fila[3] = usuario.getApellidos();
					fila[4] = usuario.getDireccion();
					fila[5] = usuario.getEmail();
					fila[6] = usuario.getCelular();
					fila[7] = ninia.getDescripcionEntrada();
					((DefaultTableModel) table.getModel()).addRow(fila);
					
				}
				}
				catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al consultar");
				}
				
				
			
			}
		});
		btnConsultarTodas.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnConsultarTodas.setBounds(585, 31, 164, 33);
		contentPane.add(btnConsultarTodas);
	}

	public JScrollPane getScrollPane() {
		return scrollPane;
	}
}
