import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.RegistroSaludControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class RegistroSalud extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtPeso;
	private JTextField txtAltura;
	private JTextField txtTension;
	private JTextField txtDescripcion;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroSalud frame = new RegistroSalud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistroSalud() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(RegistroSalud.class.getResource("/images/logo.jpg")));
		setTitle("Registro de Salud Ni\u00F1a");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 634, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblRegistroSaludNia = new JLabel("REGISTRO SALUD NI\u00D1A");
		lblRegistroSaludNia.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistroSaludNia.setBounds(10, 11, 598, 45);
		lblRegistroSaludNia.setForeground(Color.RED);
		lblRegistroSaludNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		contentPane.add(lblRegistroSaludNia);

		JLabel lblNiadocumento = new JLabel("Ni\u00F1a Documento:");
		lblNiadocumento.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNiadocumento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNiadocumento.setBounds(23, 77, 201, 14);
		contentPane.add(lblNiadocumento);

		txtDocumento = new JTextField();
		txtDocumento.setBounds(234, 77, 156, 20);
		txtDocumento.setColumns(10);
		contentPane.add(txtDocumento);

		JLabel lblNewLabel = new JLabel("Peso:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(23, 102, 201, 14);
		contentPane.add(lblNewLabel);

		txtPeso = new JTextField();
		txtPeso.setBounds(234, 106, 86, 20);
		contentPane.add(txtPeso);
		txtPeso.setColumns(10);

		JLabel lblAltura = new JLabel("Altura(cm):");
		lblAltura.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAltura.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAltura.setBounds(23, 131, 201, 14);
		contentPane.add(lblAltura);

		txtAltura = new JTextField();
		txtAltura.setBounds(234, 132, 86, 20);
		contentPane.add(txtAltura);
		txtAltura.setColumns(10);

		JLabel lblTension = new JLabel("Tension:");
		lblTension.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTension.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTension.setBounds(23, 162, 201, 14);
		contentPane.add(lblTension);

		txtTension = new JTextField();
		txtTension.setBounds(234, 163, 86, 20);
		contentPane.add(txtTension);
		txtTension.setColumns(10);

		JLabel lblDescripcin = new JLabel("Descripci\u00F3n:");
		lblDescripcin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDescripcin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDescripcin.setBounds(23, 187, 201, 14);
		contentPane.add(lblDescripcin);

		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(234, 188, 314, 73);
		contentPane.add(txtDescripcion);
		txtDescripcion.setColumns(10);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnRegistrar.setBounds(223, 287, 143, 31);
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
				 RegistroSaludControlador controller = new RegistroSaludControlador();
				 controller.insert(Long.parseLong(txtDocumento.getText()), Integer.parseInt(txtPeso.getText()), Double.parseDouble(txtAltura.getText()), Integer.parseInt(txtTension.getText()), txtDescripcion.getText());
				 JOptionPane.showMessageDialog(null, "Registro de salud agregado correctamente");
				}
				catch (Exception e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "ERROR agregando registro de salud");
				}
			}
		});
		contentPane.add(btnRegistrar);
	}

}
