import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DTO.NiniaDTO;
import DTO.RegistroSaludDTO;
import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.RegistroSaludControlador;
import controlador.UsuarioControlador;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class ActualizarNinia extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocEntra;
	private JLabel lblId;
	private JTextField txtId;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JTextField txtDescripcion;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JButton btnActualizar;
	private JLabel lblActualizarNia;
	private JTextField txtCelular;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActualizarNinia frame = new ActualizarNinia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ActualizarNinia() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ActualizarNinia.class.getResource("/images/logo.jpg")));
		setTitle("Actualizar Ni\u00F1a");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 572, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("Documento:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(188, 19, 139, 17);
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		txtDocEntra = new JTextField();
		txtDocEntra.setBounds(331, 19, 144, 20);
		txtDocEntra.setColumns(10);
		
		JButton button = new JButton("Consultar");
		button.setBounds(331, 45, 117, 33);
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					NiniaControlador controlNinia = new NiniaControlador();
					UsuarioControlador controlUsuario = new UsuarioControlador();
					
					NiniaDTO ninia = controlNinia.findByPk(Long.parseLong(txtDocEntra.getText()));
					UsuarioDTO usuario = controlUsuario.findByPk(ninia.getUsuarioDocumento());
					
					txtId.setText(Integer.toString(ninia.getId()));
					txtNombres.setText(usuario.getNombres());
					txtApellidos.setText(usuario.getApellidos());
					txtDireccion.setText(usuario.getDireccion());
					txtCelular.setText(usuario.getCelular());
					txtEmail.setText(usuario.getEmail());					
					
					
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al consultar la ni�a");
					}
				
			}
		});
		
		lblId = new JLabel("Id:");
		lblId.setBounds(19, 118, 176, 17);
		lblId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		txtId = new JTextField();
		txtId.setBounds(205, 115, 265, 17);
		txtId.setColumns(10);
		
		txtNombres = new JTextField();
		txtNombres.setBounds(205, 146, 266, 20);
		txtNombres.setColumns(10);
		
		txtApellidos = new JTextField();
		txtApellidos.setBounds(205, 172, 265, 20);
		txtApellidos.setColumns(10);
		
		txtDireccion = new JTextField();
		txtDireccion.setBounds(206, 265, 265, 20);
		txtDireccion.setColumns(10);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(204, 296, 267, 88);
		txtDescripcion.setColumns(10);
		
		label_3 = new JLabel("Descripci\u00F3n:");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(20, 293, 175, 17);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(20, 268, 175, 17);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		label_5 = new JLabel("Apellidos:");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(19, 175, 176, 17);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		label_6 = new JLabel("Nombres:");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setBounds(19, 146, 176, 17);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.setBounds(176, 399, 151, 33);
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
				NiniaControlador controlNinia = new NiniaControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				
				controlUsuario.update(Long.parseLong(txtDocEntra.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText(), txtEmail.getText(), txtCelular.getText(), "F");
				controlNinia.update(Integer.parseInt(txtId.getText()), Long.parseLong(txtDocEntra.getText()), txtDescripcion.getText());
				JOptionPane.showMessageDialog(null, "Datos actualizados");
				}
				catch (Exception e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al actualizar datos");
				}
				
				
			}
		});
		btnActualizar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		lblActualizarNia = new JLabel("ACTUALIZAR NI\u00D1A");
		lblActualizarNia.setHorizontalAlignment(SwingConstants.CENTER);
		lblActualizarNia.setBounds(19, 16, 211, 45);
		lblActualizarNia.setForeground(Color.RED);
		lblActualizarNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		
		JLabel label_7 = new JLabel("Email (opcional):");
		label_7.setHorizontalAlignment(SwingConstants.RIGHT);
		label_7.setBounds(20, 237, 175, 17);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel label_8 = new JLabel("Celular:");
		label_8.setHorizontalAlignment(SwingConstants.RIGHT);
		label_8.setBounds(20, 209, 175, 17);
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		txtCelular = new JTextField();
		txtCelular.setBounds(206, 203, 265, 20);
		txtCelular.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(206, 234, 265, 20);
		txtEmail.setColumns(10);
		contentPane.setLayout(null);
		contentPane.add(lblId);
		contentPane.add(txtId);
		contentPane.add(label_6);
		contentPane.add(label_8);
		contentPane.add(txtCelular);
		contentPane.add(label_7);
		contentPane.add(txtEmail);
		contentPane.add(label_4);
		contentPane.add(label_3);
		contentPane.add(txtDescripcion);
		contentPane.add(txtDireccion);
		contentPane.add(label_5);
		contentPane.add(txtNombres);
		contentPane.add(txtApellidos);
		contentPane.add(lblActualizarNia);
		contentPane.add(label);
		contentPane.add(txtDocEntra);
		contentPane.add(button);
		contentPane.add(btnActualizar);
	}
}
