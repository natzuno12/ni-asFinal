import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.postgresql.shaded.com.ongres.scram.common.util.UsAsciiUtils;

import DTO.TipoUsuarioDTO;
import DTO.UsuarioDTO;
import controlador.TipoUsuarioControlador;
import controlador.UsuarioControlador;
import stack.StackArray;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class ConsultarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField txtDocumento;
	private JLabel lblConsultarFuncionario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultarFuncionario frame = new ConsultarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConsultarFuncionario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ConsultarFuncionario.class.getResource("/images/logo.jpg")));
		setTitle("Consultar Funcionario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 941, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 138, 905, 221);

		JLabel label = new JLabel("Documento:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label.setBounds(10, 64, 113, 14);

		txtDocumento = new JTextField();
		txtDocumento.setBounds(127, 61, 144, 20);
		txtDocumento.setColumns(10);

		JButton button = new JButton("Consultar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.setBounds(127, 87, 144, 34);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try{
				TipoUsuarioControlador controlFuncionario = new TipoUsuarioControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				
				TipoUsuarioDTO funcionario = controlFuncionario.findByPk(Long.parseLong(txtDocumento.getText()));
				UsuarioDTO usuario = controlUsuario.findByPk(funcionario.getUsuarioDocumento());
				
				DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
				while(dm.getRowCount()>0){
					dm.removeRow(0);
				}
				if(funcionario.getUsuarioDocumento()!=0){
				int numCols = table.getModel().getColumnCount();
				Object[] fila = new Object[numCols];

				fila[0] = funcionario.getTipo();
				fila[1] = usuario.getDocumento();
				fila[2] = usuario.getNombres();
				fila[3] = usuario.getApellidos();
				fila[4] = usuario.getCelular();
				fila[5] = usuario.getDireccion();
				fila[6] = usuario.getGenero();
				((DefaultTableModel) table.getModel()).addRow(fila);
				}else{
					JOptionPane.showMessageDialog(null, "El funcionario no existe en la base de datos");
				}
				}
				catch (Exception ee) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al buscar el funcionario");
				}
			}
		});

		lblConsultarFuncionario = new JLabel("CONSULTAR FUNCIONARIO");
		lblConsultarFuncionario.setHorizontalAlignment(SwingConstants.CENTER);
		lblConsultarFuncionario.setBounds(10, 10, 905, 45);
		lblConsultarFuncionario.setForeground(Color.RED);
		lblConsultarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		
		JButton btnCosultTodo = new JButton("Consultar Todos");
		btnCosultTodo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCosultTodo.setBounds(684, 76, 190, 34);
		btnCosultTodo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				TipoUsuarioControlador controlFuncionario = new TipoUsuarioControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				
				StackArray<TipoUsuarioDTO> funcionarios = controlFuncionario.findAll();
				
				DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
				while(dm.getRowCount()>0){
					dm.removeRow(0);
				}
				
				for(int i=0 ; i<funcionarios.getSize()-1 ; i++){
					
					TipoUsuarioDTO funcionario = funcionarios.pop();
					
					if(!funcionario.getTipo().equals("Familiar")){
					UsuarioDTO usuario = controlUsuario.findByPk(funcionario.getUsuarioDocumento());
					
					
					int numCols = table.getModel().getColumnCount();
					Object[] fila = new Object[numCols];

					fila[0] = funcionario.getTipo();
					fila[1] = usuario.getDocumento();
					fila[2] = usuario.getNombres();
					fila[3] = usuario.getApellidos();
					fila[4] = usuario.getCelular();
					fila[5] = usuario.getDireccion();
					fila[6] = usuario.getGenero();
					((DefaultTableModel) table.getModel()).addRow(fila);
					}
				}
				}
				catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al consultar");
				}
				
				
			}
		});
		contentPane.setLayout(null);

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Tipo", "Documento", "Nombres", "Apellidos", "Celular", "Direcci\u00F3n", "Genero"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(146);
		table.getColumnModel().getColumn(1).setPreferredWidth(102);
		table.getColumnModel().getColumn(2).setPreferredWidth(150);
		table.getColumnModel().getColumn(3).setPreferredWidth(149);
		table.getColumnModel().getColumn(4).setPreferredWidth(164);
		table.getColumnModel().getColumn(5).setPreferredWidth(126);
		table.getColumnModel().getColumn(6).setPreferredWidth(52);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		contentPane.add(lblConsultarFuncionario);
		contentPane.add(label);
		contentPane.add(txtDocumento);
		contentPane.add(button);
		contentPane.add(btnCosultTodo);
	}
}
