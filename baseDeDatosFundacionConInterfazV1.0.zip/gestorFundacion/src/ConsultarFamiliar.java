import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import DTO.TipoUsuarioDTO;
import DTO.TipoUsuarioNiniaDTO;
import DTO.UsuarioDTO;
import controlador.TipoUsuarioControlador;
import controlador.TipoUsuarioNiniaControlador;
import controlador.UsuarioControlador;
import stack.StackArray;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class ConsultarFamiliar extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField txtDocumento;
	private JLabel lblConsultarFamiliar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultarFamiliar frame = new ConsultarFamiliar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void consultarFamiliares(Long documento){
		try{
		TipoUsuarioNiniaControlador controlFamiliares = new TipoUsuarioNiniaControlador();
		UsuarioControlador controlUsuario = new UsuarioControlador();
		
		StackArray<TipoUsuarioNiniaDTO> relaciones = controlFamiliares.findAll();
		
		DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
		while(dm.getRowCount()>0){
			dm.removeRow(0);
		}
		
		for(int i=0 ; i<relaciones.getSize()-1 ; i++){
			
			TipoUsuarioNiniaDTO relacion = relaciones.pop();
			
			if(relacion.getNiniaDocumento()==documento){
				
				UsuarioDTO familiar = controlUsuario.findByPk(relacion.getTipoUsuarioDocumento());
				
				int numCols = table.getModel().getColumnCount();
				Object[] fila = new Object[numCols];
				
				fila[0] = familiar.getDocumento();
				fila[1] = familiar.getNombres();
				fila[2] = familiar.getApellidos();
				fila[3] = familiar.getCelular();
				fila[4] = familiar.getDireccion();
				fila[5] = familiar.getGenero();
				((DefaultTableModel) table.getModel()).addRow(fila);
				
				
			}
			
		}
		}
		catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "Error al buscar familiares");
		}
		
		
	}

	/**
	 * Create the frame.
	 */
	public ConsultarFamiliar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ConsultarFamiliar.class.getResource("/images/logo.jpg")));
		setTitle("Consultar Familiar");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 910, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 143, 874, 205);

		JLabel label = new JLabel("Documento:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label.setBounds(234, 69, 157, 14);

		txtDocumento = new JTextField();
		txtDocumento.setBounds(397, 66, 162, 20);
		txtDocumento.setColumns(10);

		JButton button = new JButton("Consultar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.setBounds(397, 97, 100, 35);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
				
				TipoUsuarioControlador controlFamiliar = new TipoUsuarioControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				
				TipoUsuarioDTO familiar = controlFamiliar.findByPk(Long.parseLong(txtDocumento.getText()));	
				
				DefaultTableModel dm = (DefaultTableModel) table.getModel(); //limpiar tabla
				while(dm.getRowCount()>0){
					dm.removeRow(0);
				}
				
				if(familiar.getTipo().equals("Familiar")){
					UsuarioDTO usuario = controlUsuario.findByPk(familiar.getUsuarioDocumento());
					
					
					int numCols = table.getModel().getColumnCount();
					Object[] fila = new Object[numCols];

					fila[0] = usuario.getDocumento();
					fila[1] = usuario.getNombres();
					fila[2] = usuario.getApellidos();
					fila[3] = usuario.getCelular();
					fila[4] = usuario.getDireccion();
					fila[5] = usuario.getGenero();
					((DefaultTableModel) table.getModel()).addRow(fila);
					
				}else {
					throw new Exception();
				}
				
				
				
				
				}
				catch (Exception e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al buscar el familiar");
				}
			}
		});	
		

		lblConsultarFamiliar = new JLabel("CONSULTAR FAMILIAR");
		lblConsultarFamiliar.setHorizontalAlignment(SwingConstants.CENTER);
		lblConsultarFamiliar.setBounds(10, 15, 874, 45);
		lblConsultarFamiliar.setForeground(Color.RED);
		lblConsultarFamiliar.setFont(new Font("Cooper Black", Font.BOLD, 14));

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Documento", "Nombres", "Apellidos", "Celular", "Direcci\u00F3n", "Genero"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(104);
		table.getColumnModel().getColumn(1).setPreferredWidth(116);
		table.getColumnModel().getColumn(2).setPreferredWidth(102);
		table.getColumnModel().getColumn(3).setPreferredWidth(148);
		table.getColumnModel().getColumn(4).setPreferredWidth(113);
		table.getColumnModel().getColumn(5).setPreferredWidth(31);
		scrollPane.setViewportView(table);
		contentPane.setLayout(null);
		contentPane.add(lblConsultarFamiliar);
		contentPane.add(label);
		contentPane.add(txtDocumento);
		contentPane.add(scrollPane);
		contentPane.add(button);
	}
}
