import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.TipoUsuarioControlador;
import controlador.TipoUsuarioNiniaControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class RegistroFamiliar extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;
	private JComboBox comboBoxGenero;
	private long documentoNinia;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroFamiliar frame = new RegistroFamiliar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void setDocumentoNinia(long documento){
		this.documentoNinia = documento;
	}

	/**
	 * Create the frame.
	 */
	public RegistroFamiliar() {
		setTitle("Registrar Familiar");
		setIconImage(Toolkit.getDefaultToolkit().getImage(RegistroFamiliar.class.getResource("/images/logo.jpg")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 565, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblRegistrarFamiliar = new JLabel("REGISTRAR FAMILIAR");
		lblRegistrarFamiliar.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarFamiliar.setForeground(Color.RED);
		lblRegistrarFamiliar.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarFamiliar.setBounds(10, 11, 529, 45);
		contentPane.add(lblRegistrarFamiliar);

		JLabel lblDocumentoDelFamiliar = new JLabel("Documento del Familiar:");
		lblDocumentoDelFamiliar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDocumentoDelFamiliar.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDocumentoDelFamiliar.setBounds(22, 83, 200, 14);
		contentPane.add(lblDocumentoDelFamiliar);

		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(226, 83, 156, 20);
		contentPane.add(txtDocumento);

		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					UsuarioControlador controlUsuario = new UsuarioControlador();
					TipoUsuarioNiniaControlador controlRelacion = new TipoUsuarioNiniaControlador();
					UsuarioDTO usuario = new UsuarioDTO();
					usuario = controlUsuario.findByPk(Long.parseLong((txtDocumento.getText())));
					if(usuario.getDocumento() == 0){
					controlUsuario.insert(Long.parseLong(txtDocumento.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText(), " ", txtCelular.getText(), (String) comboBoxGenero.getSelectedItem() );
					TipoUsuarioControlador controlFamliar = new TipoUsuarioControlador();
					controlFamliar.insert((int) (Math.random() * 9999) + 1, Long.parseLong(txtDocumento.getText()), "Familiar");
					controlRelacion.insertar(Long.parseLong(txtDocumento.getText()), documentoNinia);
					JOptionPane.showMessageDialog(null, "Familiar agregado");
					System.out.print("Operacion exitosa");
					}else {
						JOptionPane.showMessageDialog(null, "El familiar ya existe");
					}
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al agregar familiar");
					}
			}
		});
		btnRegistrar.setBounds(184, 270, 139, 33);
		contentPane.add(btnRegistrar);

		JLabel label_1 = new JLabel("Nombres:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(22, 106, 200, 14);
		contentPane.add(label_1);

		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(226, 106, 265, 20);
		contentPane.add(txtNombres);

		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(22, 131, 200, 14);
		contentPane.add(label_2);

		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(226, 131, 265, 20);
		contentPane.add(txtApellidos);

		JLabel label_3 = new JLabel("Celular:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(22, 154, 200, 14);
		contentPane.add(label_3);

		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(226, 154, 191, 20);
		contentPane.add(txtCelular);

		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(22, 179, 200, 14);
		contentPane.add(label_4);

		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(226, 179, 265, 20);
		contentPane.add(txtDireccion);

		JLabel label_5 = new JLabel("Genero:");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(22, 204, 200, 14);
		contentPane.add(label_5);

		comboBoxGenero = new JComboBox();
		comboBoxGenero.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		comboBoxGenero.setBounds(226, 204, 70, 20);
		contentPane.add(comboBoxGenero);
	}
}
