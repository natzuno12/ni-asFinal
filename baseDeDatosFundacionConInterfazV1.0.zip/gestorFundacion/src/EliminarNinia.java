import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.NiniaDTO;
import controlador.NiniaControlador;
import controlador.RegistroSaludControlador;
import controlador.TipoUsuarioNiniaControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class EliminarNinia extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JLabel lblEliminarNia;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarNinia frame = new EliminarNinia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EliminarNinia() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(EliminarNinia.class.getResource("/images/logo.jpg")));
		setTitle("Eliminar Ni\u00F1a");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDocumento = new JLabel("Documento:");
		lblDocumento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDocumento.setBounds(34, 103, 144, 14);
		contentPane.add(lblDocumento);
		
		txtDocumento = new JTextField();
		txtDocumento.setBounds(188, 100, 144, 20);
		contentPane.add(txtDocumento);
		txtDocumento.setColumns(10);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				NiniaControlador controlNinia = new NiniaControlador();
				UsuarioControlador controlUsuario = new UsuarioControlador();
				TipoUsuarioNiniaControlador controlRelacion = new TipoUsuarioNiniaControlador();
				RegistroSaludControlador controlRegistro = new RegistroSaludControlador();
				
				NiniaDTO ninia = controlNinia.findByPk(Long.parseLong(txtDocumento.getText()));
				
				controlRelacion.delete(ninia.getUsuarioDocumento());
				controlRegistro.delete(ninia.getUsuarioDocumento());
				controlNinia.delete(ninia.getUsuarioDocumento());	
				controlUsuario.delete(ninia.getUsuarioDocumento());
				
				JOptionPane.showMessageDialog(null, "Ni�a eliminada");
				}
				catch (Exception ee) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al eliminar ni�a");
				}
			}
		});
		btnEliminar.setBounds(153, 175, 105, 34);
		contentPane.add(btnEliminar);
		
		lblEliminarNia = new JLabel("ELIMINAR NI\u00D1A");
		lblEliminarNia.setHorizontalAlignment(SwingConstants.CENTER);
		lblEliminarNia.setForeground(Color.RED);
		lblEliminarNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblEliminarNia.setBounds(10, 11, 414, 45);
		contentPane.add(lblEliminarNia);
	}

}
