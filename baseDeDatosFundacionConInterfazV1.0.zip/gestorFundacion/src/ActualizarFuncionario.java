import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.NiniaDTO;
import DTO.TipoUsuarioDTO;
import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.TipoUsuarioControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class ActualizarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtCelular;
	private JTextField txtDireccion;
	private JTextField txtDocEntra;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActualizarFuncionario frame = new ActualizarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ActualizarFuncionario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ActualizarFuncionario.class.getResource("/images/logo.jpg")));
		setTitle("Actualizar Funcionario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 528, 401);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label_1 = new JLabel("Nombres:");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_1.setBounds(24, 155, 153, 14);
		contentPane.add(label_1);

		txtNombres = new JTextField();
		txtNombres.setColumns(10);
		txtNombres.setBounds(186, 152, 266, 20);
		contentPane.add(txtNombres);

		JLabel label_2 = new JLabel("Apellidos:");
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_2.setBounds(24, 177, 153, 14);
		contentPane.add(label_2);

		txtApellidos = new JTextField();
		txtApellidos.setColumns(10);
		txtApellidos.setBounds(187, 174, 265, 20);
		contentPane.add(txtApellidos);

		JLabel label_3 = new JLabel("Celular:");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_3.setBounds(24, 200, 153, 14);
		contentPane.add(label_3);

		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(187, 197, 191, 20);
		contentPane.add(txtCelular);

		JLabel label_4 = new JLabel("Direcci\u00F3n:");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_4.setBounds(24, 225, 153, 14);
		contentPane.add(label_4);

		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(187, 222, 265, 20);
		contentPane.add(txtDireccion);

		JLabel label_5 = new JLabel("Genero:");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_5.setBounds(24, 250, 153, 14);
		contentPane.add(label_5);

		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		comboBox.setBounds(187, 247, 70, 20);
		contentPane.add(comboBox);

		JLabel lblActualizarFuncionario = new JLabel("ACTUALIZAR FUNCIONARIO");
		lblActualizarFuncionario.setHorizontalAlignment(SwingConstants.CENTER);
		lblActualizarFuncionario.setForeground(Color.RED);
		lblActualizarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblActualizarFuncionario.setBounds(10, 11, 471, 45);
		contentPane.add(lblActualizarFuncionario);

		JLabel label_6 = new JLabel("Documento:");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_6.setBounds(24, 60, 159, 14);
		contentPane.add(label_6);

		txtDocEntra = new JTextField();
		txtDocEntra.setColumns(10);
		txtDocEntra.setBounds(187, 57, 144, 20);
		contentPane.add(txtDocEntra);

		JButton button = new JButton("Consultar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					TipoUsuarioControlador controlFuncionario = new TipoUsuarioControlador();
					UsuarioControlador controlUsuario = new UsuarioControlador();
					
					TipoUsuarioDTO funcionario = controlFuncionario.findByPk(Long.parseLong(txtDocEntra.getText()));
					UsuarioDTO usuario = controlUsuario.findByPk(funcionario.getUsuarioDocumento());			
					
					txtNombres.setText(usuario.getNombres());
					txtApellidos.setText(usuario.getApellidos());
					txtDireccion.setText(usuario.getDireccion());
					txtCelular.setText(usuario.getCelular());
					
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al consultar el funcionario");
					}
			}
		});
		button.setBounds(187, 83, 109, 29);
		contentPane.add(button);

		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					TipoUsuarioControlador controlFuncionario = new TipoUsuarioControlador();
					UsuarioControlador controlUsuario = new UsuarioControlador();
					
					controlUsuario.update(Long.parseLong(txtDocEntra.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText()," ", txtCelular.getText(), (String) comboBox.getSelectedItem());
					TipoUsuarioDTO funcionario = controlFuncionario.findByPk(Long.parseLong(txtDocEntra.getText()));
					controlFuncionario.update(funcionario.getCodigo(), funcionario.getUsuarioDocumento() , funcionario.getTipo());
					JOptionPane.showMessageDialog(null, "Datos actualizados");
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al actualizar datos");
					}
			}
		});
		btnActualizar.setBounds(187, 299, 124, 41);
		contentPane.add(btnActualizar);
	}

}
