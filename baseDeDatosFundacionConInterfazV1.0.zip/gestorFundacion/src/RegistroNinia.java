import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.UsuarioDTO;
import controlador.NiniaControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class RegistroNinia extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JTextField txtId;
	private JTextField txtNombres;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JTextField txtDescripcion;
	private JTextField txtCelular;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistroNinia frame = new RegistroNinia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistroNinia() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(RegistroNinia.class.getResource("/images/logo.jpg")));
		setTitle("Registrar Ni\u00F1a");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 604, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistrarNia = new JLabel("REGISTRAR NI\u00D1A");
		lblRegistrarNia.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarNia.setForeground(new Color(255, 0, 0));
		lblRegistrarNia.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblRegistrarNia.setBounds(198, 11, 198, 45);
		contentPane.add(lblRegistrarNia);
		
		JLabel lblDocumento = new JLabel("Documento:");
		lblDocumento.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDocumento.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDocumento.setBounds(10, 84, 192, 14);
		contentPane.add(lblDocumento);
		
		JLabel lblId = new JLabel("Id:");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblId.setBounds(10, 109, 192, 14);
		contentPane.add(lblId);
		
		JLabel lblNombres = new JLabel("Nombres:");
		lblNombres.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNombres.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNombres.setBounds(10, 134, 192, 14);
		contentPane.add(lblNombres);
		
		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblApellidos.setHorizontalAlignment(SwingConstants.RIGHT);
		lblApellidos.setBounds(10, 159, 192, 14);
		contentPane.add(lblApellidos);
		
		JLabel lblDireccin = new JLabel("Direcci\u00F3n:");
		lblDireccin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDireccin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDireccin.setBounds(10, 188, 192, 14);
		contentPane.add(lblDireccin);
		
		txtDocumento = new JTextField();
		txtDocumento.setBounds(212, 81, 156, 20);
		contentPane.add(txtDocumento);
		txtDocumento.setColumns(10);
		
		txtId = new JTextField();
		txtId.setBounds(212, 106, 265, 17);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtNombres = new JTextField();
		txtNombres.setBounds(211, 131, 266, 20);
		contentPane.add(txtNombres);
		txtNombres.setColumns(10);
		
		txtApellidos = new JTextField();
		txtApellidos.setBounds(212, 156, 265, 20);
		contentPane.add(txtApellidos);
		txtApellidos.setColumns(10);
		
		txtDireccion = new JTextField();
		txtDireccion.setBounds(212, 187, 265, 20);
		contentPane.add(txtDireccion);
		txtDireccion.setColumns(10);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n:");
		lblDescripcin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDescripcin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDescripcin.setBounds(10, 275, 192, 14);
		contentPane.add(lblDescripcin);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setBounds(210, 278, 267, 88);
		contentPane.add(txtDescripcion);
		txtDescripcion.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
				UsuarioControlador controlUsuario = new UsuarioControlador();
				UsuarioDTO usuario = new UsuarioDTO();
				usuario = controlUsuario.findByPk(Long.parseLong((txtDocumento.getText())));
				if(usuario.getDocumento() == 0){
				controlUsuario.insert(Long.parseLong(txtDocumento.getText()), txtNombres.getText(), txtApellidos.getText(), txtDireccion.getText(), txtEmail.getText(), txtCelular.getText(), "F");
				NiniaControlador controlNinia = new NiniaControlador();
				controlNinia.insert(Integer.parseInt(txtId.getText()), Long.parseLong((txtDocumento.getText())), txtDescripcion.getText());
				txtDescripcion.setText(usuario.getApellidos());
				JOptionPane.showMessageDialog(null, "ni�a registrada en la base de datos");
				System.out.print("Operacion exitosa");
				}else {
					JOptionPane.showMessageDialog(null, "La ni�a ya existe en la base de datos");
				}
				}
				catch (Exception e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error al agregar ni�a");
				}
				
			}
		});
		btnRegistrar.setBounds(225, 389, 130, 37);
		contentPane.add(btnRegistrar);
		
		JLabel lblEmail = new JLabel("Email (opcional):");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblEmail.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEmail.setBounds(10, 248, 192, 14);
		contentPane.add(lblEmail);
		
		txtCelular = new JTextField();
		txtCelular.setColumns(10);
		txtCelular.setBounds(212, 217, 265, 20);
		contentPane.add(txtCelular);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(212, 245, 265, 20);
		contentPane.add(txtEmail);
		
		JLabel lblCelular = new JLabel("Celular:");
		lblCelular.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCelular.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCelular.setBounds(10, 218, 192, 14);
		contentPane.add(lblCelular);
	}
}
