import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToggleButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLayeredPane;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class SubPrincipal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SubPrincipal frame = new SubPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SubPrincipal() {
		setTitle("Base de Datos Fundacion");
		setIconImage(Toolkit.getDefaultToolkit().getImage(SubPrincipal.class.getResource("/images/logo.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 594, 376);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.setBounds(23, 0, 528, 21);
		contentPane.add(menuBar);
		
		JMenu mnArchivo = new JMenu("Archivo");
		mnArchivo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnArchivo);
		
		JMenuItem mntmSalir = new JMenuItem("Salir");
		mntmSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnArchivo.add(mntmSalir);
		
		JMenu mnUsuario = new JMenu("Usuario");
		mnUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnUsuario);
		
		JMenu mnRegistrar = new JMenu("Registrar");
		mnUsuario.add(mnRegistrar);
		
		JMenuItem mntmNia_3 = new JMenuItem("Ni\u00F1a");
		mntmNia_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RegistroNinia registrarNinia = new RegistroNinia();
				registrarNinia.setVisible(true);
			}
		});
		mnRegistrar.add(mntmNia_3);
		
		JMenuItem mntmFuncionario = new JMenuItem("Funcionario");
		mntmFuncionario.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				RegistrarFuncionario registrarFun = new RegistrarFuncionario();
				registrarFun.setVisible(true);
			}
		});
		mnRegistrar.add(mntmFuncionario);
		
		JMenuItem mntmSaludNia = new JMenuItem("Salud Ni\u00F1a");
		mntmSaludNia.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				
				RegistroSalud registroSalud = new RegistroSalud ();
				registroSalud.setVisible(true);
			}
		});
		mnRegistrar.add(mntmSaludNia);
		
		JMenuBar menuBar_1 = new JMenuBar();
		mnRegistrar.add(menuBar_1);
		
		JMenu mnConsultar = new JMenu("Consultar");
		mnUsuario.add(mnConsultar);
		
		JMenuItem mntmNia_1 = new JMenuItem("Ni\u00F1a");
		mntmNia_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ConsultarNinia consultarNinia = new ConsultarNinia();
				consultarNinia.setVisible(true);
			}
		});
		mnConsultar.add(mntmNia_1);
		
		JMenuItem mntmFuncionario_1 = new JMenuItem("Funcionario");
		mntmFuncionario_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ConsultarFuncionario consultarFuncionario = new ConsultarFuncionario();
				consultarFuncionario.setVisible(true);
			}
		});
		mnConsultar.add(mntmFuncionario_1);
		
		JMenuItem mntmFamiliar_1 = new JMenuItem("Familiar");
		mntmFamiliar_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ConsultarFamiliar consultarFamiliar = new ConsultarFamiliar();
				consultarFamiliar.setVisible(true);
			}
		});
		mnConsultar.add(mntmFamiliar_1);
		
		JMenu mnEliminar = new JMenu("Eliminar");
		mnUsuario.add(mnEliminar);
		
		JMenuItem mntmNia_2 = new JMenuItem("Ni\u00F1a");
		mntmNia_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				EliminarNinia eliminarNinia = new EliminarNinia ();
				eliminarNinia.setVisible(true);
			}
		});
		mnEliminar.add(mntmNia_2);
		
		JMenu mnActualizar = new JMenu("Actualizar");
		mnUsuario.add(mnActualizar);
		
		JMenuItem mntmNia = new JMenuItem("Ni\u00F1a");
		mntmNia.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ActualizarNinia actNinia = new ActualizarNinia();
				actNinia.setVisible(true);
			}
		});
		mnActualizar.add(mntmNia);
		
		JMenuItem mntmFuncionario_3 = new JMenuItem("Funcionario");
		mntmFuncionario_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				ActualizarFuncionario actFun = new ActualizarFuncionario();
				actFun.setVisible(true);
			}
		});
		mnActualizar.add(mntmFuncionario_3);
		
		JMenu mnAyuda = new JMenu("Ayuda");
		mnAyuda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnAyuda);
		
		JMenu mnAcercaDe = new JMenu("Acerca de...");
		mnAyuda.add(mnAcercaDe);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(SubPrincipal.class.getResource("/images/logo.jpg")));
		lblNewLabel.setBounds(114, 26, 346, 300);
		contentPane.add(lblNewLabel);
	}
}
