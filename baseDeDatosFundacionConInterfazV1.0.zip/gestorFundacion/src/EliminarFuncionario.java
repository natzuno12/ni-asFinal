import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DTO.TipoUsuarioDTO;
import controlador.NiniaControlador;
import controlador.TipoUsuarioControlador;
import controlador.UsuarioControlador;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Toolkit;

public class EliminarFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtDocumento;
	private JLabel lblEliminarFuncionario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EliminarFuncionario frame = new EliminarFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EliminarFuncionario() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(EliminarFuncionario.class.getResource("/images/logo.jpg")));
		setTitle("Eliminar Funcionario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("Documento:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label.setBounds(30, 107, 154, 14);
		contentPane.add(label);

		txtDocumento = new JTextField();
		txtDocumento.setColumns(10);
		txtDocumento.setBounds(186, 104, 144, 20);
		contentPane.add(txtDocumento);

		JButton button = new JButton("Eliminar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 14));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					TipoUsuarioControlador controlTipo = new TipoUsuarioControlador();
					UsuarioControlador controlUsuario = new UsuarioControlador();
					TipoUsuarioDTO funcionario = controlTipo.findByPk(Long.parseLong(txtDocumento.getText()));
					controlTipo.delete(funcionario.getUsuarioDocumento());		
					controlUsuario.delete(funcionario.getUsuarioDocumento());
					
					JOptionPane.showMessageDialog(null, "Funcionario eliminado");
					}
					catch (Exception ee) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "Error al eliminar funcionario");
					}
			}
		});
		button.setBounds(162, 169, 108, 37);
		contentPane.add(button);

		lblEliminarFuncionario = new JLabel("ELIMINAR FUNCIONARIO");
		lblEliminarFuncionario.setHorizontalAlignment(SwingConstants.CENTER);
		lblEliminarFuncionario.setForeground(Color.RED);
		lblEliminarFuncionario.setFont(new Font("Cooper Black", Font.BOLD, 14));
		lblEliminarFuncionario.setBounds(10, 11, 414, 45);
		contentPane.add(lblEliminarFuncionario);
	}

}
