package DTO;

public class TipoUsuarioDTO implements Crud {

	private int codigo;
	private long usuarioDocumento;
	private String tipo;
	
	public TipoUsuarioDTO(int codigo, long usuarioDocumento, String tipo) {
		super();
		this.codigo = codigo;
		this.usuarioDocumento = usuarioDocumento;
		this.tipo = tipo;
	}
	
	public TipoUsuarioDTO() {}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public long getUsuarioDocumento() {
		return usuarioDocumento;
	}

	public void setUsuarioDocumento(long usuarioDocumento) {
		this.usuarioDocumento = usuarioDocumento;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "TipoUsuarioDTO [codigo=" + codigo + ", usuarioDocumento=" + usuarioDocumento + ", tipo=" + tipo + "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.tipo_usuario(\n" + 
				"	codigo, usuario_documento, tipo)\n" + 
				"	VALUES ("+codigo+", "+usuarioDocumento+", '"+tipo+"');";
	}

	@Override
	public String update() {
		return "UPDATE public.tipo_usuario\n" + 
				"	SET codigo="+codigo+", usuario_documento="+usuarioDocumento+", tipo='"+tipo+"'\n" + 
				"	WHERE usuario_documento="+usuarioDocumento+";";
	}

	@Override
	public String delete() {
		return "DELETE FROM public.tipo_usuario\n" + 
				"	WHERE usuario_documento="+usuarioDocumento+";";
	}

	@Override
	public String findByPk() {
		return "SELECT *" + 
				" FROM public.tipo_usuario WHERE usuario_documento = "+usuarioDocumento+";";
	}

	@Override
	public String findAll() {
		return "SELECT codigo, usuario_documento, tipo\n" + 
				"	FROM public.tipo_usuario;";
	}	
	
	
}
