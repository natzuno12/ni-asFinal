package DTO;

import java.sql.Date;
import java.sql.Timestamp;

public class RegistroSaludDTO implements Crud{
	
	private long niniaDocumento;
	private Timestamp fechaRegistro;
	private int peso;
	private double altura;
	private int tension;
	private String descripcionCondicion;
	
	public RegistroSaludDTO(long niniaDocumento, int peso, double altura, int tension, //la fecha la da la bd
			String descripcionCondicion) {
		super();
		this.niniaDocumento = niniaDocumento;
		this.peso = peso;
		this.altura = altura;
		this.tension = tension;
		this.descripcionCondicion = descripcionCondicion;
	}
	
	public RegistroSaludDTO() {	}

	public long getNiniaDocumento() {
		return niniaDocumento;
	}

	public void setNiniaDocumento(long niniaDocumento) {
		this.niniaDocumento = niniaDocumento;
	}

	public Timestamp getFechaRestro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Timestamp fechaRestro) {
		this.fechaRegistro = fechaRestro;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public int getTension() {
		return tension;
	}

	public void setTension(int tension) {
		this.tension = tension;
	}

	public String getDescripcionCondicion() {
		return descripcionCondicion;
	}

	public void setDescripcionCondicion(String descripcionCondicion) {
		this.descripcionCondicion = descripcionCondicion;
	}

	@Override
	public String toString() {
		return "RegistroSaludDTO [niniaDocumento=" + niniaDocumento + ", fecha_registro=" + fechaRegistro.toGMTString() + ", peso=" + peso
				+ ", altura=" + altura + ", tension=" + tension + ", descripcion_condicion=" + descripcionCondicion
				+ "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.registro_salud(\n" + 
				"	ninia_documento, fecha_registro, peso, altura, tension, descripcion_condicion)\n" + 
				"	VALUES ("+niniaDocumento+", CURRENT_TIMESTAMP, "+peso+", "+altura+", "+tension+", '"+descripcionCondicion+"');";
	}

	@Override
	public String update() {
		return "UPDATE public.registro_salud\n" + 
				"	SET ninia_documento="+niniaDocumento+", peso="+peso+", altura="+altura+", tension="+tension+", descripcion_condicion='"+descripcionCondicion+"'\n" + 
				"	WHERE ninia_documento="+niniaDocumento+" ;";
	}

	@Override
	public String delete() {
		return "DELETE FROM public.registro_salud\n" + 
				"	WHERE ninia_Documento="+niniaDocumento+";";
	}

	@Override
	public String findByPk() {
		return "SELECT *" + 
				" FROM public.registro_salud WHERE ninia_Documento="+niniaDocumento+";";
	}

	@Override
	public String findAll() {
		return "SELECT *\n" + 
				"	FROM public.registro_salud;";
	}
	
	

}
