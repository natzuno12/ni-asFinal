package DTO;

import java.util.List;

import interfaces.CrudDAO;

public class NiniaDTO implements Crud {

	private int id;
	private long usuarioDocumento;	
	private String descripcionEntrada;
	
	public NiniaDTO(int id, long usuarioDocumento, String descripcionEntrada) {
		super();
		this.id = id;
		this.usuarioDocumento = usuarioDocumento;
		this.descripcionEntrada = descripcionEntrada;
	}
	
	public NiniaDTO() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getUsuarioDocumento() {
		return usuarioDocumento;
	}

	public void setUsuarioDocumento(long usuarioDocumento) {
		this.usuarioDocumento = usuarioDocumento;
	}

	public String getDescripcionEntrada() {
		return descripcionEntrada;
	}

	public void setDescripcionEntrada(String descripcionEntrada) {
		this.descripcionEntrada = descripcionEntrada;
	}
	
	@Override
	public String toString() {
		return "NiniaDTO [id=" + id + ", usuarioDocumento=" + usuarioDocumento + ", descripcionEntrada="
				+ descripcionEntrada + "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.ninia(\n" + 
				"	id, descripcion_entrada, usuario_documento)\n" + 
				"	VALUES ("+id+",'"+descripcionEntrada+"', "+usuarioDocumento+");";
	}

	@Override
	public String update() {
		return "UPDATE public.ninia\n" + 
				"	SET id="+id+", descripcion_entrada='"+descripcionEntrada+"', usuario_documento="+usuarioDocumento+"\n" + 
				"	WHERE id="+id+";";
	}

	@Override
	public String delete() {
		return "DELETE FROM public.ninia\n" + 
				"	WHERE usuario_documento="+usuarioDocumento+";";
	}

	@Override
	public String findByPk() {
		return "SELECT *" + 
				" FROM public.ninia WHERE usuario_documento = "+usuarioDocumento+";";
	}

	@Override
	public String findAll() {
		return "SELECT *\n" + 
				"	FROM public.ninia;";
	}
	
	
	
	
}
