package DTO;

import java.math.BigInteger;

public class UsuarioDTO implements Crud { //TODO IMPLEMENTAR CONSULTAS SQL

	private long documento;
	private String nombres;
	private String apellidos;
	private String direccion;
	private String email;
	private String celular;
	private String genero;
	
	public UsuarioDTO(long documento, String nombres, String apellidos, String direccion, String email, String celular,
			String genero) {
		super();
		this.documento = documento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.direccion = direccion;
		this.email = email;
		this.celular = celular;
		this.genero = genero;
	}
	
	public UsuarioDTO() {}
	
	public long getDocumento() {
		return documento;
	}
	public void setDocumento(long documento) {
		this.documento = documento;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}	
	
	@Override
	public String toString() {
		return "UsuarioDTO [documento=" + documento + ", nombres=" + nombres + ", apellidos=" + apellidos
				+ ", direccion=" + direccion + ", email=" + email + ", celular=" + celular + ", genero=" + genero + "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.usuario(\n" + 
				"	documento, nombres, apellidos, direccion, email, celular, genero)\n" + 
				"	VALUES ("+documento+", '"+nombres+"', '"+apellidos+"', '"+direccion+"', '"+email+"', "+celular+", '"+genero+"');";
	}
	@Override
	public String update() {
		return "UPDATE public.usuario\n" + 
				"	SET documento="+documento+", nombres='"+nombres+"', apellidos='"+apellidos+"', direccion='"+direccion+"', email='"+email+"', celular="+celular+", genero='"+genero+"'\n" + 
				"	WHERE documento="+documento+";";
	}
	@Override
	public String delete() {
		return "DELETE FROM public.usuario\n" + 
				"	WHERE documento="+documento+";";
	}
	@Override
	public String findByPk() {
		return "SELECT *\n" + 
				"	FROM public.usuario WHERE documento="+documento+";";
	}
	@Override
	public String findAll() {
		return "SELECT *\n" + 
				"	FROM public.usuario;";
	}
	
	
	
	
}
