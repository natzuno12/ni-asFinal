package DTO;

public class GeneroDTO implements Crud{

	private String genero;
	private int id; 
			
	public GeneroDTO( int id, String genero) {
		super();
		this.genero = genero;
		this.id = id;
	}
	
	public GeneroDTO() {}

	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "GeneroDTO [genero=" + genero + ", id=" + id + "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.genero(\n" + 
				"	id, genero)\n" + 
				"	VALUES ("+id+", '"+genero+"');";
	}	
	
	@Override
	public String update() {
		return "UPDATE public.genero" + 
				" SET genero='"+genero+"'" + 
				" WHERE id="+id+";";
	}

	@Override
	public String delete() {
		return "DELETE FROM public.genero" + 
				" WHERE id="+id+";";
	}

	@Override
	public String findByPk() {
		return "SELECT *" + 
				" FROM public.genero WHERE id = "+id+";";
	}

	@Override
	public String findAll() {
		return "SELECT id, genero\n" + 
				"	FROM public.genero;";
	}

}
