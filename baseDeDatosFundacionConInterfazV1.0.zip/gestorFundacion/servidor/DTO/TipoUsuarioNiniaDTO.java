package DTO;

public class TipoUsuarioNiniaDTO implements Crud{

	private long tipoUsuarioDocumento;
	private long niniaDocumento;
	
	public TipoUsuarioNiniaDTO(long tipoUsuarioDocumento, long niniaDocumento) {
		super();
		this.tipoUsuarioDocumento = tipoUsuarioDocumento;
		this.niniaDocumento = niniaDocumento;
	}
	
	public TipoUsuarioNiniaDTO() {}

	public long getTipoUsuarioDocumento() {
		return tipoUsuarioDocumento;
	}

	public void setTipoUsuarioDocumento(long tipoUsuarioDocumento) {
		this.tipoUsuarioDocumento = tipoUsuarioDocumento;
	}

	public long getNiniaDocumento() {
		return niniaDocumento;
	}

	public void setNiniaDocumento(long niniaDocumento) {
		this.niniaDocumento = niniaDocumento;
	}

	@Override
	public String toString() {
		return "TipoUsuarioNiniaDTO [TipoUsuarioCodigo=" + tipoUsuarioDocumento + ", niniaDocumento=" + niniaDocumento
				+ "]";
	}

	@Override
	public String insert() {
		return "INSERT INTO public.tipo_usuario_ninia(\n" + 
				"	tipo_usuario_documento, ninia_documento)\n" + 
				"	VALUES ("+tipoUsuarioDocumento+", "+niniaDocumento+");";
	}

	@Override
	public String update() {
		return "UPDATE public.tipo_usuario_ninia\n" + 
				"	SET tipo_usuario_documento="+tipoUsuarioDocumento+", ninia_documento="+niniaDocumento+"\n" + 
				"	WHERE ninia_documento="+niniaDocumento+";";
	}

	@Override
	public String delete() {
		return "DELETE FROM public.tipo_usuario_ninia\n" + 
				"	WHERE ninia_documento="+niniaDocumento+";";
	}

	@Override
	public String findByPk() {
		return "SELECT *" + 
				" FROM public.tipo_usuario_ninia WHERE ninia_documento="+niniaDocumento+";";
	}

	@Override
	public String findAll() {
		return "SELECT tipo_usuario_documento, ninia_documento\n" + 
				"	FROM public.tipo_usuario_ninia;";
	}
	
	
}
