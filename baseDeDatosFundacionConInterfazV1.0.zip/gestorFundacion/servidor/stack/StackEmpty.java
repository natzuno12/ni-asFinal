package stack;

public class StackEmpty extends Exception{

	public StackEmpty(String message) {
		super(message);
	}
}
