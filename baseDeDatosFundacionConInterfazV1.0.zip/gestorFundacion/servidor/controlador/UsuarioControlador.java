package controlador;
import DTO.UsuarioDTO;
import stack.StackArray;

import java.math.BigInteger;
import java.util.List;

import DAO.UsuarioDAO;

public class UsuarioControlador {

	public UsuarioDAO dao;
	
	public UsuarioControlador() {
		dao = new UsuarioDAO();
	}
	
	public boolean insert(long documento, String nombres, String apellidos,
							String direccion, String email, String celular, String genero) {
		UsuarioDTO objeto = new UsuarioDTO(documento, nombres, apellidos, direccion,
								email, celular, genero);
		return dao.insert(objeto);
	}

	public boolean update(long documento, String nombres, String apellidos,
							String direccion, String email, String celular, String genero) {
		UsuarioDTO objeto = new UsuarioDTO(documento, nombres, apellidos, direccion,
				email, celular, genero);
		return dao.update(objeto);
	}
	
	public boolean delete(long documento) {
		UsuarioDTO objeto = new UsuarioDTO();
		objeto.setDocumento(documento);
		return dao.delete(objeto);
	}
	
	public UsuarioDTO findByPk(long documento) {
		UsuarioDTO objeto = new UsuarioDTO();
		objeto.setDocumento(documento);
		return dao.getByPk(objeto);
	}
	
	public StackArray<UsuarioDTO> findAll() {
		UsuarioDTO objeto = new UsuarioDTO();
		return dao.getFindAll(objeto);
	}	
	
}
