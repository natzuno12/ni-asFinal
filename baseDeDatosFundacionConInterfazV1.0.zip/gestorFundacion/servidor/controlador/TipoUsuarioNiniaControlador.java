package controlador;

import java.util.List;

import DAO.TipoUsuarioNiniaDAO;
import DTO.TipoUsuarioNiniaDTO;
import stack.StackArray;

public class TipoUsuarioNiniaControlador {
	
	TipoUsuarioNiniaDAO dao = new TipoUsuarioNiniaDAO();
	
	public boolean insertar(long tipoUsuarioCodigo, long niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO(tipoUsuarioCodigo, niniaDocumento);
		return dao.insert(objeto);
	}
	
	public boolean update(long tipoUsuarioCodigo, long niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO(tipoUsuarioCodigo, niniaDocumento);
		return dao.insert(objeto);
	}
	
	public boolean delete(long niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.delete(objeto);
	}
	
	public TipoUsuarioNiniaDTO findByPk(long niniaDocumento) {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		objeto.setNiniaDocumento(niniaDocumento);
		return dao.getByPk(objeto);
	}
	
	public StackArray<TipoUsuarioNiniaDTO> findAll() {
		TipoUsuarioNiniaDTO objeto = new TipoUsuarioNiniaDTO();
		return dao.getFindAll(objeto);
	}
	
}
