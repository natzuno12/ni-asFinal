package controlador;

import java.util.List;

import DAO.NiniaDAO;
import DTO.NiniaDTO;
import stack.StackArray;

public class NiniaControlador {
	
	NiniaDAO dao;

	public NiniaControlador() {
		dao = new NiniaDAO();
	}
	
	public boolean insert(int id, long usuarioDocumento,
							String descripcionEntrada) {
		NiniaDTO objeto = new NiniaDTO(id, usuarioDocumento, descripcionEntrada);
		return dao.insert(objeto);
	}
	
	public boolean update(int id, long usuarioDocumento,
							String descripcionEntrada) {
		NiniaDTO objeto = new NiniaDTO(id, usuarioDocumento, descripcionEntrada);
		return dao.update(objeto);
	}
	
	public boolean delete(long documento) {
		NiniaDTO objeto = new NiniaDTO();
		objeto.setUsuarioDocumento(documento);
		return dao.delete(objeto);
	}
	
	public NiniaDTO findByPk(long documento){
		NiniaDTO objeto = new NiniaDTO();
		objeto.setUsuarioDocumento(documento);
		return dao.getByPk(objeto);
	}
	
	public StackArray<NiniaDTO> findAll(){
		NiniaDTO objeto = new NiniaDTO();
		return dao.getFindAll(objeto);
	}
	
}
