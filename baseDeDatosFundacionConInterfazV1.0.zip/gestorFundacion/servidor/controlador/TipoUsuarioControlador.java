package controlador;

import java.util.List;

import DAO.TipoUsuarioDAO;
import DTO.TipoUsuarioDTO;
import stack.StackArray;

public class TipoUsuarioControlador {

	TipoUsuarioDAO dao = new TipoUsuarioDAO();
	
	public boolean insert(int codigo, long usuarioDocumento, String tipo) {
		TipoUsuarioDTO objeto = new TipoUsuarioDTO(codigo, usuarioDocumento, tipo);
		return dao.insert(objeto);
	}
	
	public boolean update(int codigo, long usuarioDocumento, String tipo) {
		TipoUsuarioDTO objeto = new TipoUsuarioDTO(codigo, usuarioDocumento, tipo);
		return dao.update(objeto);
	}
	
	public boolean delete(long documento) {
		TipoUsuarioDTO objeto = new TipoUsuarioDTO();
		objeto.setUsuarioDocumento((documento));
		return dao.delete(objeto);
	}
	
	public TipoUsuarioDTO findByPk(long documento) {
		TipoUsuarioDTO objeto = new TipoUsuarioDTO();
		objeto.setUsuarioDocumento((documento));
		return dao.getByPk(objeto);
	}
	
	public StackArray<TipoUsuarioDTO> findAll(){
		TipoUsuarioDTO objeto = new TipoUsuarioDTO();
		return dao.getFindAll(objeto);
	}
	
}
