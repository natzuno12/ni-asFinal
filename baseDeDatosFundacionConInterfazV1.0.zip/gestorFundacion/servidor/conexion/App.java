package conexion;

public class App {

	public App() {
		Conexion con = Conexion.getInstance();
	}

	public static void main(String[] args) {
		new App();
	}
}
