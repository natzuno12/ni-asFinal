package conexion;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Conexion {
	private static Conexion conexion = null;
	private Connection con = null;
	private Statement st;

	private Conexion() {
		Properties dataConex = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("data/conexion.properties");
			dataConex.load(input);

			String url = dataConex.getProperty("url");
			String user = dataConex.getProperty("user");
			String password = dataConex.getProperty("password");

			con = DriverManager.getConnection(url, user, password);

			System.out.println("Datos para conexion cargados...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Conexion getInstance() {
		if (conexion == null) {
			conexion = new Conexion();
		}
		return conexion;
	}

	public ResultSet getQuery(String query) {
		ResultSet rs = null;
		try {
			st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public boolean executeQuery(String query) {
		boolean ex = false;
		try {
			st = con.createStatement();
			ex = st.execute(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ex;
	}

}
