package DAO;

import DTO.RegistroSaludDTO;

public class RegistroSaludDAO extends GenericDAO<RegistroSaludDTO> {

	public RegistroSaludDAO() {
		super(RegistroSaludDTO.class);
	}

}
