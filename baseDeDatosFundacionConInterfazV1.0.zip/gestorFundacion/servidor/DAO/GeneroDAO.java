package DAO;

import DTO.GeneroDTO;

public class GeneroDAO extends GenericDAO<GeneroDTO>{

	public GeneroDAO() {
		super(GeneroDTO.class);
	}
	
	public static void main(String[] args) {
		GeneroDAO v = new GeneroDAO();
		GeneroDTO g = new GeneroDTO();
		g.setId(5);
		System.out.println(v.getByPk(g));
		System.out.println("----------------------");
		g.setId(10);
		v.delete(g);
		System.out.println(v.getFindAll(g));		
		
	}
}
