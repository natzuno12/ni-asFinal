package DAO;

import DTO.TipoUsuarioNiniaDTO;

public class TipoUsuarioNiniaDAO extends GenericDAO<TipoUsuarioNiniaDTO>{

	public TipoUsuarioNiniaDAO() {
		super(TipoUsuarioNiniaDTO.class);
	}
	
	
}
